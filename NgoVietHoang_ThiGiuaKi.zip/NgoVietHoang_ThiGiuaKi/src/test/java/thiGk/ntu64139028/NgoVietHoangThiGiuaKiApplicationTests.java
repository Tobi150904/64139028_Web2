package thiGk.ntu64139028;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NgoVietHoangThiGiuaKiApplicationTests {

	@Test
	void contextLoads() {
	}

}
